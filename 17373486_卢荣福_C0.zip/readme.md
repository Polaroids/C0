* 编译代码
 ```
mkdir build
cd build
cmake ..
make
 ```
* 使用方式

  ```
  Options:
    -s        将输入的 c0 源代码翻译为文本汇编文件
    -c        将输入的 c0 源代码翻译为二进制目标文件
    -h        显示关于编译器使用的帮助
    -o file   输出到指定的文件 file
  ```

* 完成内容

  * basic

* 未定义行为
  1. 未赋值的int默认为0
  2. int超出直接截断
  3. 没有return的函数自动增加`ret`或者`iret`

